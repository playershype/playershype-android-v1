# PlayersHype Android Ecosystem V1.3 RC

V1.3 RC closes the current PlayersHype Android cycle around reliable HypePredict export and Public Live publication. It preserves the V1.2 visual Home, no-code Control Center, Track Hub and the existing HypePredict V1 analysis/rendering core.

## V1.3 RC scope

- Fixes the Admin export failure that returned `Recurso no disponible` when the packaged public export template was requested.
- Adds one shared **Public Live Service** used by both HypePredict and Control Center.
- Adds manual tools for `index.html`, timestamped public HTML copy, Admin/work HTML copy, workspace JSON, preview/open and publication history.
- Adds **ACTUALIZAR LIVE**: generate public index -> create local backup -> commit `docs/index.html` to GitHub -> return the commit/status.
- Replaces the old HypePredict Live Worker/KV publication bridge with GitHub publication.
- Stores the GitHub fine-grained token encrypted with Android Keystore; the token is never embedded in exported HTML or JavaScript configuration.
- Keeps a local internal HTML backup before each publication attempt. Failed publication remains visible as **Pendiente de publicar**.
- User app HypePredict refreshes the canonical public index directly from the public GitHub repository, not from the old HypePredict Live Worker.
- Android build workflow ignores `docs/**` changes, so updating the Live does not rebuild the APKs.

## HypePredict V1 protection

The analysis/rendering core was not changed for V1.3 RC. `scripts/v13_static_audit.py` removes only the explicitly allowed publication UI/bridge surfaces and verifies the remaining HypePredict module against the protected V1.2 core SHA-256. It also verifies the official V1 weights literal remains:

`pace 1.45 · trip 1.00 · class 2.20 · distance 1.90 · form 1.50 · consistency 1.05 · weight 0.60 · works 0.30 = 10.00`

## Public Live source of truth

Default publication target:

- Repository: `playershype/playershype-android-v1`
- Branch: `main`
- Path: `docs/index.html`
- User-app read source: `https://raw.githubusercontent.com/playershype/playershype-android-v1/main/docs/index.html`

The browser-facing Live can be served from GitHub Pages (`main` / `docs`) or from Cloudflare Pages connected to GitHub. No Cloudflare Worker/KV is required for HypePredict Live publication.

## One-time setup after installing the Admin RC

Open **Control Center -> HypePredict · Public Live -> Conexión GitHub** and enter the repository owner, repository, branch, index path, public Live URL and a fine-grained GitHub token with Contents read/write access only to the PlayersHype Android repository. The token is encrypted in Android Keystore on that phone.

See `docs/PUBLIC_LIVE_V1.3.md` and `V1.3-RC-IMPLEMENTED.md`.
