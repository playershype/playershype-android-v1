(()=>{'use strict';
if(window.HypeLive)return;
let generated=null;
const STORAGE_KEY='hypepredict.cardLibrary.v1',TRACK_KEY='hypepredict.trackRegistry.v1',POST_KEY='hypepredict.postmortemHistory.v1',THEME_KEY='hypepredict.viewerTheme.v1';
const nowStamp=()=>new Date().toISOString().replace(/[:.]/g,'-').slice(0,19);
function parse(raw,fallback){try{const v=JSON.parse(raw);return v??fallback}catch(_){return fallback}}
function workspace(){
  const cards=parse(localStorage.getItem(STORAGE_KEY)||'[]',[]);
  const tracks=parse(localStorage.getItem(TRACK_KEY)||'[]',[]);
  return {cards:Array.isArray(cards)?cards:[],tracks:Array.isArray(tracks)?tracks:[]};
}
async function ensureExport(){if(window.HypeExportsReady)await window.HypeExportsReady;if(!window.HypeExports)throw new Error('El generador público todavía no está listo.');}
async function generate(cards,tracks){
  await ensureExport();
  const list=Array.isArray(cards)?cards:workspace().cards, registry=Array.isArray(tracks)?tracks:workspace().tracks;
  if(!list.length)throw new Error('No hay jornadas cargadas para generar el index.');
  const html=window.HypeExports.public(list,registry,false);
  generated={html,createdAt:new Date().toISOString(),cards:list.length,bytes:new Blob([html],{type:'text/html'}).size};
  return {...generated,html:undefined};
}
function getGenerated(){if(!generated)throw new Error('Primero genera el index.html.');return generated;}
function saveText(text,name){const blob=new Blob([text],{type:'text/html;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);return name;}
function saveIndex(){const g=getGenerated();return saveText(g.html,'index.html');}
function saveCopy(){const g=getGenerated();return saveText(g.html,`HypePredict-Public-${nowStamp()}.html`);}

async function saveAdminCopy(){
  await ensureExport();
  const w=workspace(); if(!w.cards.length)throw new Error('No hay jornadas cargadas para guardar el HTML de trabajo.');
  const r=await fetch('/assets/hypepredict/admin.html',{cache:'no-store'}); if(!r.ok)throw new Error('No pude abrir el HTML de trabajo empaquetado.');
  const doc=new DOMParser().parseFromString(await r.text(),'text/html');
  const data=doc.querySelector('#embeddedData'),tracks=doc.querySelector('#embeddedTrackRegistry'),ws=doc.querySelector('#embeddedWorkspaceState');
  if(data)data.textContent=JSON.stringify(w.cards).replace(/</g,'\u003c');
  if(tracks)tracks.textContent=JSON.stringify(w.tracks).replace(/</g,'\u003c');
  if(ws)ws.textContent=JSON.stringify({format:'HypePredict Admin Snapshot',version:'1.3',savedAt:new Date().toISOString(),theme:localStorage.getItem(THEME_KEY)||'light',postmortemHistory:parse(localStorage.getItem(POST_KEY)||'[]',[])}).replace(/</g,'\u003c');
  const app=doc.querySelector('#app'); if(app)app.innerHTML='';
  const html=window.HypeExports.admin(doc.documentElement);
  return saveText(html,`HypePredict-ADMIN-${nowStamp()}.html`);
}

function saveWorkspaceBackup(){const w=workspace(),payload={format:'HypePredict Workspace Backup',formatVersion:1,createdAt:new Date().toISOString(),cards:w.cards,trackRegistry:w.tracks};const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`HypePredict-Workspace-${nowStamp()}.json`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);return a.download;}
async function status(){if(!window.HypeAndroid)return {configured:false,webOnly:true};return JSON.parse(await HypeAndroid.request('publisherStatus'));}
async function history(){if(!window.HypeAndroid)return [];return JSON.parse(await HypeAndroid.request('publisherHistory'));}
async function configure(cfg){if(!window.HypeAndroid)throw new Error('La publicación automática requiere el Admin APK.');return JSON.parse(await HypeAndroid.request('publisherConfigure',cfg));}
async function clearToken(){if(!window.HypeAndroid)throw new Error('La publicación automática requiere el Admin APK.');return JSON.parse(await HypeAndroid.request('publisherClearToken'));}
async function publishHtml(html,message='Update HypePredict Live'){
  if(!window.HypeAndroid)throw new Error('La publicación automática requiere el Admin APK.');
  const blob=new Blob([html],{type:'text/html'});let transfer;
  try{
    transfer=await HypeAndroid.request('publishBegin',{name:'index.html',mime:'text/html',size:blob.size});
    for(let start=0;start<blob.size;start+=196608){
      const bytes=new Uint8Array(await blob.slice(start,start+196608).arrayBuffer());let binary='';
      for(let k=0;k<bytes.length;k+=8192)binary+=String.fromCharCode(...bytes.subarray(k,k+8192));
      await HypeAndroid.request('publishChunk',{transfer,data:btoa(binary)});
    }
    return JSON.parse(await HypeAndroid.request('publishFinish',{transfer,message}));
  }catch(err){if(transfer)HypeAndroid.request('publishAbort',{transfer}).catch(()=>{});throw err;}
}
async function publishGenerated(message){return publishHtml(getGenerated().html,message);}
async function updateLive(cards,tracks,message){await generate(cards,tracks);return publishGenerated(message||'Update HypePredict Live');}
async function openLive(){const s=await status();if(!s.liveUrl)throw new Error('Configura primero la URL pública del Live.');await HypeAndroid.request('external',{url:s.liveUrl});return s.liveUrl;}
window.HypeLive=Object.freeze({workspace,generate,getGenerated,saveIndex,saveCopy,saveAdminCopy,saveWorkspaceBackup,status,history,configure,clearToken,publishGenerated,updateLive,openLive});
})();
