"""Bundle verified V1.3 RC APKs plus build evidence and rebuildable source.

Source inventory is filesystem-based because CI may build this source after expanding an
opaque SOURCE.zip inside a parent Git repository; `git ls-files` would then describe the
parent repo instead of this extracted source tree.
"""
from __future__ import annotations
import hashlib
import os
import pathlib
import subprocess
import zipfile

R = pathlib.Path(__file__).resolve().parents[1]
OUT = R / "artifacts"
OUT.mkdir(exist_ok=True)


def build_commit() -> str:
    env_sha = os.environ.get("GITHUB_SHA", "").strip()
    if env_sha:
        return env_sha
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=R, text=True, stderr=subprocess.DEVNULL).strip()
    except Exception:
        return "unavailable"


def source_files():
    blocked_dirs = {".git", ".gradle", "build", "artifacts", "emulator-evidence", "node_modules", ".idea"}
    blocked_ext = {".jks", ".keystore", ".p12", ".pfx", ".apk", ".aab"}
    for path in sorted(R.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(R)
        if any(part in blocked_dirs for part in rel.parts):
            continue
        if path.suffix.lower() in blocked_ext:
            continue
        yield rel, path


commit = build_commit()
(OUT / "BUILD_COMMIT.txt").write_text(commit + "\n", encoding="utf-8")
files = list(source_files())

for role, module in [("App", "app-user"), ("Admin", "app-admin")]:
    name = f"PlayersHype-{role}-V1.3-RC-PREVIEW.apk"
    apk = OUT / name
    if not apk.exists():
        raise SystemExit(f"Missing expected APK: {apk}")
    digest = hashlib.sha256(apk.read_bytes()).hexdigest()
    (OUT / (name + ".sha256")).write_text(digest + "  " + name + "\n", encoding="utf-8")
    print(name, digest)

    master = OUT / f"PlayersHype-{role}-V1.3-RC-MASTER-PACKAGE.zip"
    with zipfile.ZipFile(master, "w", zipfile.ZIP_DEFLATED) as z:
        for extra in [
            apk,
            OUT / (name + ".sha256"),
            OUT / "BUILD_COMMIT.txt",
            OUT / "SIGNING.txt",
            OUT / f"{role}-signature.txt",
            OUT / f"{role}-metadata.txt",
        ]:
            if extra.exists():
                z.write(extra, extra.name)
        for report_module in [module, "shared"]:
            report_root = R / report_module / "build"
            for folder in ["reports", "test-results"]:
                root = report_root / folder
                if not root.exists():
                    continue
                for report in root.rglob("*"):
                    if report.is_file():
                        z.write(report, "verification/" + report_module + "/" + report.relative_to(report_root).as_posix())
        for report_name in ["security-audit.txt", "ui-tests.txt", "v13-static-audit.txt"]:
            report = OUT / report_name
            if report.exists():
                z.write(report, "verification/" + report_name)
        for rel, path in files:
            z.write(path, "source/" + rel.as_posix())

with zipfile.ZipFile(OUT / "PlayersHype-Ecosystem-V1.3-RC-MASTER-PACKAGE.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for role in ["App", "Admin"]:
        p = OUT / f"PlayersHype-{role}-V1.3-RC-MASTER-PACKAGE.zip"
        z.write(p, p.name)
    for p in (R / "docs").glob("*.md"):
        z.write(p, "docs/" + p.name)
