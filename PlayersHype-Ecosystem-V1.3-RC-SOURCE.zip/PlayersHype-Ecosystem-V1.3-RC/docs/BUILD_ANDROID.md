# Android Build — V1.3 RC

GitHub Actions is the authoritative build gate.

The workflow runs security/static audits, JavaScript integration tests, Android unit tests, lint, preview signing, APK signature/metadata verification, packaging and emulator smoke tests.

Expected preview artifacts:

- `PlayersHype-App-V1.3-RC-PREVIEW.apk`
- `PlayersHype-Admin-V1.3-RC-PREVIEW.apk`
- `PlayersHype-Ecosystem-V1.3-RC-MASTER-PACKAGE.zip`

Both applications use versionCode 4 / versionName `1.3.0-preview` for Preview builds. Live `docs/**` commits are ignored by the Android build trigger.
