# PlayersHype Android Ecosystem V1.3.2 RC

Stability patch. HypePredict V1 analysis logic is unchanged.

- HypePredict Live stays at `https://hypepredict-live.players-hype1.workers.dev/`.
- `Generar index` and `ACTUALIZAR LIVE` create/save `index.html` for manual Cloudflare publication.
- `Abrir Live` opens the existing Cloudflare Live without GitHub configuration.
- `ACTUALIZAR APP` is separate and exports the general PlayersHype app configuration for manual publication.
- Control Center and HypePredict use the same unscoped local card library; old snapshot-scoped cards are no longer the packaged default.
- The public app refreshes HypePredict from the Cloudflare Live and keeps the last verified local copy when refresh fails.
- GitHub publishing code remains available only as future/optional infrastructure; it is not required for the current manual Live flow.
