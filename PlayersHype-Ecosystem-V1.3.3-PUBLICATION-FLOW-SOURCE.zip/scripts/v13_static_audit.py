from pathlib import Path
import hashlib
import re
import sys

R=Path(__file__).resolve().parents[1]
checks={}
user_gradle=(R/'app-user/build.gradle').read_text()
admin_gradle=(R/'app-admin/build.gradle').read_text()
secure=(R/'shared/src/main/java/com/playershype/shared/SecureActivity.java').read_text()
publisher=(R/'shared/src/main/java/com/playershype/shared/PublishController.java').read_text()
feed=(R/'shared/src/main/java/com/playershype/shared/PublicFeedStore.java').read_text()
live=(R/'shared/src/main/assets/native/live-publish.js').read_text()
control=(R/'app-admin/src/main/assets/control.js').read_text()
control_html=(R/'app-admin/src/main/assets/index.html').read_text()
admin_html=(R/'app-admin/src/main/assets/hypepredict/admin.html').read_text()
module=(R/'app-admin/src/main/assets/hypepredict/module.js').read_text()
workflow=(R/'.github/workflows/build-apk.yml').read_text()

checks['app version code 4']=all('versionCode 4' in s for s in [user_gradle,admin_gradle])
checks['app version 1.3.0']=all("versionName '1.3.0'" in s for s in [user_gradle,admin_gradle])
checks['admin export template unblocked']='if(!isAdmin()&&path!=null&&(path.endsWith("public-template.html")||path.endsWith("public-seed.json")))' in secure.replace(' ','')
checks['public template remains blocked']='public-template.html' in secure and 'public-seed.json' in secure
checks['publisher is native admin-only']='if(isAdmin())publisher=newPublishController(this,io);' in secure.replace(' ','') and 'if (!admin) throw new IllegalArgumentException("Admin only")' in publisher
checks['publisher stores token encrypted']=all(x in publisher for x in ['AndroidKeyStore','AES/GCM/NoPadding','encrypt(token)','decryptToken()'])
checks['publisher has pending-safe backup']=all(x in publisher for x in ['pendingBackup','pendingAt','lastError','backup(source)'])
checks['live service supports full toolset']=all(x in live for x in ['saveIndex','saveCopy','saveAdminCopy','saveWorkspaceBackup','publishGenerated','updateLive','openLive'])
checks['control center exposes public live']=all(x in control_html for x in ['live-generate','live-save-index','live-save-copy','live-save-admin-copy','live-backup-json','live-publish-generated','live-update','live-open'])
checks['control center has secure GitHub setup']=all(x in control_html for x in ['pub-owner','pub-repo','pub-branch','pub-path','pub-live-url','pub-token'])
checks['hypepredict admin loads live service']='/assets/native/live-publish.js' in admin_html
checks['hypepredict update live uses shared service']='window.HypeLive.updateLive' in module
checks['old Cloudflare live publish path gone']='hypepredict-live.players-hype1.workers.dev' not in module and 'hypepredict-live.players-hype1.workers.dev' not in feed
checks['results gateway preserved']='hypepredict-results.players-hype1.workers.dev/results' in module
checks['user feed reads canonical GitHub index']=all(x in feed for x in ['raw.githubusercontent.com','/playershype/playershype-android-v1/main/docs/index.html'])
checks['live commits do not trigger Android rebuild']="'docs/**'" in workflow or '"docs/**"' in workflow
checks['workflow outputs V1.3 RC']='PlayersHype-Ecosystem-V1.3-RC-Android' in workflow and 'PlayersHype-App-V1.3-RC-PREVIEW.apk' in workflow and 'PlayersHype-Admin-V1.3-RC-PREVIEW.apk' in workflow
checks['official HypePredict V1 weights preserved']='hypeScoreWeights:{pace:1.45,trip:1,class:2.2,distance:1.9,form:1.5,consistency:1.05,weight:.6,works:.3,total:10}' in module

# Protect the V1 analysis/rendering core against accidental edits. V1.3 is allowed to
# change only the two publication menu rows, the manual public-export wrapper, and the
# old publication bridge itself. Removing those surfaces leaves the exact V1.2 core.
def protected_core(text):
    lines=[]
    for line in text.splitlines():
        if 'id="publishLiveBtn"' in line or 'id="publishPublicBtn"' in line:
            continue
        if line.startswith('function generatePublicDashboard()') or line.startswith('async function generatePublicDashboard()'):
            continue
        lines.append(line)
    text='\n'.join(lines)+'\n'
    starts=[text.find(x) for x in ['/* ===== v3.05 — LIVE PUBLISH BRIDGE','/* ===== V1.3 RC · PUBLIC LIVE'] if text.find(x)>=0]
    start=min(starts) if starts else -1
    end=text.find('/* ===== v3.01 · BROADCAST MODE V1 ===== */')
    if start<0 or end<=start:
        return b''
    return (text[:start]+text[end:]).encode('utf-8')

EXPECTED_CORE_SHA256='59705d564fe4c07dc445835b7df9f6b0805bec72c57fbb031213a10b4cd5324c'
checks['HypePredict V1 core unchanged from V1.2']=hashlib.sha256(protected_core(module)).hexdigest()==EXPECTED_CORE_SHA256

for name,ok in checks.items():
    print(('PASS' if ok else 'FAIL'),'-',name)
if not all(checks.values()):
    sys.exit(1)
print(f'PASS: {sum(checks.values())} V1.3 RC controls')
