from pathlib import Path
import hashlib,sys
R=Path(__file__).resolve().parents[1]
checks={}
ug=(R/'app-user/build.gradle').read_text(); ag=(R/'app-admin/build.gradle').read_text()
feed=(R/'shared/src/main/java/com/playershype/shared/PublicFeedStore.java').read_text()
live=(R/'shared/src/main/assets/native/live-publish.js').read_text()
ctl=(R/'app-admin/src/main/assets/control.js').read_text(); html=(R/'app-admin/src/main/assets/index.html').read_text(); admin=(R/'app-admin/src/main/assets/hypepredict/admin.html').read_text(); mod=(R/'app-admin/src/main/assets/hypepredict/module.js').read_text()
checks['version code 6']=all('versionCode 6' in x for x in [ug,ag])
checks['version 1.3.2']=all("versionName '1.3.2'" in x for x in [ug,ag])
checks['cloudflare live canonical']='hypepredict-live.players-hype1.workers.dev' in feed and all('https://hypepredict-live.players-hype1.workers.dev/' in x for x in [live,ctl,html])
checks['user feed keeps cache and reads cloudflare']='AtomicFile' in feed and 'normalize(input,"cloudflare")' in feed and 'hypepredict-live.players-hype1.workers.dev' in feed
checks['packaged admin unscoped']='data-snapshot-id=' not in admin and 'data-admin-snapshot=' not in admin
checks['manual live update']=all(x in live for x in ['manual:true','saveIndex()','LEGACY_LIVE_URL']) and 'HypeLive.updateLive' in mod
checks['app and live separated']=all(x in html for x in ['live-update-app','live-update']) and 'PlayersHype-App-Config-V1.3.2-RC.json' in ctl
checks['open live no github required']='url=s.liveUrl||LEGACY_LIVE_URL' in live
checks['HypePredict V1 weights preserved']='hypeScoreWeights:{pace:1.45,trip:1,class:2.2,distance:1.9,form:1.5,consistency:1.05,weight:.6,works:.3,total:10}' in mod
for k,v in checks.items(): print(('PASS' if v else 'FAIL'),'-',k)
if not all(checks.values()): sys.exit(1)
print(f'PASS: {sum(checks.values())} V1.3.2 RC controls')
