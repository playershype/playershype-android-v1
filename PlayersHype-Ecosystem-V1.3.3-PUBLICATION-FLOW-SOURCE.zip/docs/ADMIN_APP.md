# PlayersHype Admin V1.3 RC

The Admin APK keeps the V1.2 visual no-code Control Center and adds a real HypePredict Public Live publication path.

## Control Center

The administrator can manage Hero, Player Live, social URLs, Track Hub cards, HypePredict presentation, PlayersHype TV programs, Latest items and module order without editing JSON or code.

The existing presentation configuration remains schemaVersion 2. Local Control Center drafts continue to live on the Admin device; V1.3 RC does not pretend that changing the Home configuration automatically updates every installed User APK.

## HypePredict Public Live

Control Center and the HypePredict Admin screen use the same `HypeLive` service. Available operations:

- Generate public index
- Save `index.html`
- Save timestamped public HTML copy
- Save Admin/work HTML copy
- Save workspace JSON
- Publish generated index
- ACTUALIZAR LIVE (generate + local backup + GitHub publish)
- Open Live
- View publication history/status

GitHub credentials are handled only by the native Admin publisher and the token is encrypted with Android Keystore.

## Export security

Public exports use the explicit public projection and exclude private Prompt Maestro, score components/weights, Postmortem/calibration material, raw sources and internal operational notes. The User app still cannot access the packaged Admin export template/seed resources.
