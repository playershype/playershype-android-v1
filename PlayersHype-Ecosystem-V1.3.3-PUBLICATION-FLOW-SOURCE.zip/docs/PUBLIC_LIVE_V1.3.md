# HypePredict Public Live — V1.3 RC

## Daily operator flow

1. Load/review the HypePredict day in Admin.
2. Use **Vista previa** or manually **Generar index** if desired.
3. Press **ACTUALIZAR LIVE**.
4. The Admin generates the read-only public HTML, creates a local internal backup, commits it to GitHub and reports the commit.
5. Use **Abrir Live** to verify the published browser page.

Manual tools remain available for saving `index.html`, a timestamped public HTML copy, an Admin/work HTML copy and workspace JSON.

## One-time GitHub connection

In Control Center, set:

- Owner: `playershype`
- Repository: `playershype-android-v1`
- Branch: `main`
- Index path: `docs/index.html`
- Public Live URL: the final GitHub Pages or Cloudflare Pages address
- Token: a GitHub fine-grained personal access token restricted to this repository with **Contents: Read and write**

The token is sent only to the native Android publisher and stored encrypted with Android Keystore. It is not written into the HTML, JavaScript config, local draft JSON, export or Git history.

## Failure behavior

The local HTML backup is created before the GitHub request. If the network or GitHub request fails, Control Center displays **Pendiente de publicar**, retains the backup and records the last error. The analysis/workspace remains local and can still be exported manually.

## User app refresh

The User APK reads the canonical public index directly from:

`https://raw.githubusercontent.com/playershype/playershype-android-v1/main/docs/index.html`

The public projection is validated before being cached. If refresh fails, the previous validated cache remains available.

## Browser hosting

### GitHub Pages

Configure the repository once to serve from `main` and `/docs`. The expected URL is normally:

`https://playershype.github.io/playershype-android-v1/`

### Cloudflare Pages

Cloudflare Pages may instead be connected directly to the GitHub repository and serve the same static `docs/index.html`. This uses GitHub as source of truth and does not require Worker/KV publication code.

## Android CI interaction

The Android workflow ignores `docs/**` pushes. A daily Live update therefore does not trigger a full APK build.
