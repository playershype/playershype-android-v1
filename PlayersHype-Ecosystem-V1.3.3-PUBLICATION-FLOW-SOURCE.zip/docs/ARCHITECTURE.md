# Architecture — PlayersHype Ecosystem V1.3 RC

`app-user` (`com.playershype.app`) and `app-admin` (`com.playershype.admin`) remain independent Android applications. `shared` supplies the hardened WebView shell, native file mediator, native GitHub publisher, sanitized HypePredict projection and atomic public-feed cache. Executable app assets load only from `https://appassets.androidplatform.net`.

## Admin publication path

`Control Center / HypePredict -> HypeLive -> PublishController -> GitHub Contents API -> main/docs/index.html`

`PublishController` exists only in the Admin shell. The fine-grained GitHub token is encrypted with Android Keystore and is never returned to JavaScript after configuration.

## User HypePredict path

`User app -> PublicFeedStore -> raw GitHub docs/index.html -> PublicProjection -> atomic local cache -> internal read-only Track Hub`

The prior Worker/KV Live publisher/discovery path is removed. The official-results gateway is a separate subsystem and remains unchanged.

## Browser Live

The same `docs/index.html` may be served by GitHub Pages or Cloudflare Pages connected to GitHub. GitHub remains the source of truth.

## CI

Live commits modify `docs/**`; Android build workflows ignore those paths so daily publication does not rebuild APKs.

## Unchanged product boundary

V1.3 RC adds remote publication for the HypePredict public dashboard only. It does not add a general authenticated cross-device CMS for every Home/TV/Latest configuration field; those presentation drafts remain local/exportable until a separate Core service is intentionally introduced.
