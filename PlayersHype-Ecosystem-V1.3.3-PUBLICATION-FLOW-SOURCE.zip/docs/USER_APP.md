# PlayersHype User App V1.3 RC

The V1.2 visual Home and Track Hub remain intact. Module order and visibility still use the schemaVersion 2 public presentation configuration.

## HypePredict

Predict from native navigation and the primary HypePredict CTA opens the internal read-only Track Hub. The User APK maintains a validated local HypePredict cache and refreshes the canonical public index directly from the public GitHub repository:

`https://raw.githubusercontent.com/playershype/playershype-android-v1/main/docs/index.html`

If refresh is unavailable, the previous validated local cache remains available. The old HypePredict Live Worker discovery path is no longer used.

The separate official-results gateway is unchanged in V1.3 RC.

## Public boundaries

The User app does not expose Admin import, delete, publication, gateway configuration, private Prompt Maestro, model components, Postmortem/calibration data or raw source inputs.
