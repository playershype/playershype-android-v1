# Release Notes

## V1.3 RC
- Fixed Admin public export resource blocking.
- Added shared HypePredict Public Live service to Admin HypePredict and Control Center.
- Added GitHub-native publication to `main/docs/index.html` with Android Keystore token encryption, backups, pending state and history.
- User app HypePredict now refreshes the canonical public index directly from GitHub instead of the former Live Worker discovery path.
- Android CI ignores `docs/**` Live commits.
- HypePredict V1 protected core and official weights are unchanged from V1.2.

# Release notes

## V1.2.0 — Visual Home + No-Code Control Center
- Rebuilt public Home as an image-led PlayersHype sports-media experience.
- Added explicit active/offline/coming-soon/hidden behavior so unfinished modules do not appear broken.
- Rebuilt Admin Control Center around forms, switches, URL fields, image upload, add/remove cards and simple ordering; removed JSON from the normal admin workflow.
- Player Live now has a dedicated YouTube URL/status workflow.
- PlayersHype TV now treats the YouTube channel as the primary destination, with optional per-program YouTube/video/playlist links.
- Added visual Track Hub card management and image upload.
- Added Latest content cards and social URL management.
- Added V1.2 presentation config contract (schemaVersion 2) while leaving the HypePredict public racing projection at schemaVersion 1.
- Bumped both Android applications to versionCode 3 / versionName 1.2.0.
- Included V1.2 design concepts under `docs/design/`.

### Verification status
- JavaScript syntax checks: PASS.
- Packaged V1.2 configuration validation: PASS.
- Security audit: PASS, 37 controls.
- Gradle/Android build in this runtime: NOT RUN TO COMPLETION because Gradle 8.13 is not cached and this environment cannot reach `services.gradle.org`.
- Physical Android-device testing: NOT RUN in this runtime.
- Real multi-device Publish: BLOCKED until PlayersHype Core authentication/write/public-config endpoints are supplied.

## V1.1 — Track Hub navigation fix
- Native Predict/HypePredict entry always opens Track Hub.
- Track cards may deep-link to a specific track.
- No HypePredict analysis logic or scoring was changed.
