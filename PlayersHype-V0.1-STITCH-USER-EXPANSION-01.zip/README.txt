PlayersHype V0.1 Stitch User Expansion 01
Exact source extracted from official Stitch unified architecture package.
Do not redesign; Stitch is visual source of truth.
