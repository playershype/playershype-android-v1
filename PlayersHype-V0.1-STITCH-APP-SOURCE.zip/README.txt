PlayersHype App V0.1 — Official Stitch subset

SOURCE OF TRUTH:
Extracted verbatim from stitch_playershype_ecosystem_unified_architecture.zip.

Included:
- home/code.html + screen.png
- track-hub/code.html + screen.png
- hypepredict/code.html + screen.png

Rule: Preserve Stitch visual design. Functional Android wiring may be added around/inside these sources without redesigning them.
