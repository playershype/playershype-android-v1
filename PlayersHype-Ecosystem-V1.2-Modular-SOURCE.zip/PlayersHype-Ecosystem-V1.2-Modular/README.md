# PlayersHype Android Ecosystem V1.2

V1.2 converts the public Home and Admin Control Center into a modular, visual, no-code experience while preserving the packaged HypePredict engine and the V1.1 Track Hub navigation fix.

## What changed in V1.2
- Public Home redesigned as a visual sports-media hub with image-backed Hero, Player Live, Track cards, HypePredict, PlayersHype TV and Latest.
- Dead-looking actions are replaced by explicit states: active, offline, coming soon or hidden.
- PlayersHype TV treats YouTube as the primary video destination. The default channel is `https://youtube.com/@playershype1`.
- Admin Control Center no longer exposes JSON as the normal editing workflow. It uses fields, switches, image upload buttons, status selectors and simple collections.
- Admin can manage Hero, Player Live URL/status, social URLs, Track Hub cards, HypePredict presentation, PlayersHype TV programs and Latest items.
- Images selected in Admin are downscaled/compressed in the WebView and stored in the local draft for preview/export.
- Home module order can be changed with simple up/down controls.
- V1.2 configuration contract is schemaVersion 2 and blocks executable content, credentials, non-HTTPS external links and duplicate IDs.
- HypePredict analysis logic, scoring, private Prompt Maestro and historical card renderer are not modified by the Home/Admin redesign.

## Important boundary
The no-code editor is implemented. A real **Publish to every user's phone** action still requires PlayersHype Core: authenticated write API, roles and a public configuration endpoint. Until that backend is connected, Publish validates/saves the local draft and exports the public V1.2 config; it does not pretend that remote users were updated.

See `docs/ADMIN_APP.md`, `docs/USER_APP.md`, `docs/DATA_CONTRACT.md`, `docs/PLAYERSHYPE_CORE_API.md`, and `docs/RELEASE_NOTES.md`.
