# PlayersHype User App V1.2

## Home
The Home is now a visual media/racing experience rather than a text-heavy list. It contains image-backed modules for:
- Hero / PlayersHype Network;
- Player Live;
- Hipódromos de Hoy / Track Hub;
- HypePredict;
- PlayersHype TV;
- Últimas Novedades;
- official social links when configured.

Module order and visibility come from the V1.2 public configuration. Buttons without a real destination are not presented as working actions.

## HypePredict
Predict from native navigation and the principal HypePredict CTA always open the internal Track Hub. Track cards can deep-link to a specific track. V1.2 does not change HypePredict calculation logic or the sanitized public racing feed contract.

## Player Live
The module reflects configured state. When a valid YouTube/live URL is present it opens through the system browser/app using the existing hardened external-navigation policy. When no live destination exists, the card can fall back to the configured YouTube channel or remain clearly offline.

## PlayersHype TV
YouTube is the principal destination. The default packaged channel is `https://youtube.com/@playershype1`. Programs can be Active, Próximamente or Hidden. Only Active programs with an HTTPS destination are interactive.

## Configuration source
The packaged default is `shared/src/main/assets/public-app-config.json` (schemaVersion 2). The Home can also accept a future Core configuration response without changing HypePredict's racing feed. Remote Core integration still requires endpoint/authentication work.
