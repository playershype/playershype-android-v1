# PlayersHype Core integration — required for real Publish

V1.2 completes the no-code Admin surface and the public configuration consumer. The remaining missing piece for multi-device updates is the real PlayersHype Core connection. No replacement backend is claimed or deployed by this package.

## Minimum public endpoints
Recommended contract for the existing Core service:
- `GET /api/public/app-config` → current schemaVersion 2 presentation configuration, revision, publishedAt and content hash.
- `GET /api/public/manifest` → may include `appConfig` plus public HypePredict card references for backward compatibility.
- existing/read-only HypePredict public feed/card endpoints → sanitized schemaVersion 1 racing data.

The User App V1.2 already attempts `/api/public/app-config` first when a Core URL is configured and can also accept `appConfig` nested in `/api/public/manifest`.

## Admin write workflow
Authenticated endpoints should support:
- upload/store public media (or accept bounded embedded image data and normalize it server-side);
- validate a schemaVersion 2 draft;
- preview a draft against the current public revision;
- publish using an expected-current-revision concurrency check;
- return the new immutable revision/hash;
- rollback by creating a new revision referencing a prior one rather than rewriting history.

## Authentication/security requirements
Need the actual Core repository/base URL and identity design before enabling remote publication. Use a public-client OIDC/OAuth flow appropriate for Android, short-lived scoped access tokens, server-side role enforcement, refresh/revocation rules and Android Keystore protection where applicable. Do not embed client secrets or long-lived bearer tokens in the APK.

A local `Publicar` button cannot prove remote publication. Until the Core is connected, V1.2 explicitly reports that the configuration is validated/saved but has not been sent to other users.
