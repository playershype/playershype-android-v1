# Architecture — PlayersHype Ecosystem V1.2

`app-user` (`com.playershype.app`) and `app-admin` (`com.playershype.admin`) remain independent Android applications. `shared` supplies the hardened WebView shell, native file mediator, sanitized HypePredict projection, packaged V1.2 presentation configuration and atomic racing-feed cache. Executable assets load only from `https://appassets.androidplatform.net`.

## User App
The User App now has two independent content layers:
1. **Presentation configuration V2:** Home Hero, Player Live presentation, channel URLs, track visuals, PlayersHype TV and Latest.
2. **HypePredict public feed V1:** sanitized racing cards/tracks already used by the packaged HypePredict renderer.

The visual track registry can supply images/names while the local HypePredict feed supplies the most recent available date/race count/cache state. Predict navigation remains internal to the packaged HypePredict WebView.

## Admin App
Admin contains:
- the new no-code V1.2 Control Center; and
- the existing HypePredict Admin HUB as a separate native navigation destination.

The Control Center edits a schemaVersion 2 app configuration. Normal workflows use form controls and image/URL inputs rather than JSON. Image selection uses the bounded Android document-picker bridge.

## Current publication boundary
V1.2 does **not** invent a cross-device synchronization mechanism. Admin drafts live on the Admin device and can be exported. User App ships with a packaged public default. This prevents a false impression that a local Android preference can update other users' phones.

## Target path
Authenticated Admin → PlayersHype Core → versioned V2 presentation config + sanitized HypePredict V1 publications → User App.

The target Core owns identity, authorization, media/config storage, immutable revisions, audit history and rollback. No permanent bearer token, shared APK storage or fabricated endpoint is introduced.
