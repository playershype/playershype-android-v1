# PlayersHype Admin V1.2

## Control Center
V1.2 replaces the technical JSON-draft screen with a visual no-code Control Center. The administrator can manage the public experience without editing code.

### Modules
- **Hero del Inicio:** title, subtitle, CTA destination and image upload.
- **Player Live:** active toggle, offline/scheduled/live/ended status, title, message, YouTube URL and image.
- **Redes y destinos:** YouTube / PlayersHype TV, PlayersHype.com, PlayersHype.net, Facebook, Instagram and X URLs.
- **Hipódromos / Track Hub:** add/remove tracks, edit name/ID/status/race count and upload an image.
- **HypePredict presentation:** title, description, visible version and image. This does not modify the HypePredict analysis engine.
- **PlayersHype TV:** YouTube channel URL plus per-program image, status, description and optional video/playlist URL.
- **Últimas Novedades:** image, headline, description, status and HTTPS destination.
- **Home order:** simple up/down controls.

### Images
Image selection uses the existing native Android document picker. PNG/JPEG/WEBP files are downscaled to a bounded JPEG data URL for the local draft/export. Large images are rejected instead of silently overflowing local storage.

### Validation
The V1.2 contract rejects incompatible schemas, executable HTML/JavaScript payloads, credential-like keys, non-HTTPS external links, duplicate IDs and oversized images/configurations.

## Publish boundary
`Guardar borrador` persists only on the Admin device. `Publicar` validates the configuration and prepares/exports the public V1.2 configuration, but it cannot push to other devices until PlayersHype Core is connected. No fake remote success is reported.

The original HypePredict Admin HUB remains available as the second native Admin navigation destination and retains its existing import/edit/export tooling.
