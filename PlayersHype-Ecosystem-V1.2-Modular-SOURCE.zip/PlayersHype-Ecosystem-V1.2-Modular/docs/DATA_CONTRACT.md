# PlayersHype data contracts

There are two separate public concerns in V1.2.

## 1. HypePredict racing projection — schemaVersion 1
`core-contract/public-projection.json` remains the explicit recursive allowlist for sanitized racing cards. It excludes private Prompt Maestro, model weights/components, Postmortem, calibration notes, operational notes and raw source imports. V1.2 does not change this contract.

## 2. App presentation configuration — schemaVersion 2
`core-contract/public-app-config-v2.schema.json` is the explicit JSON Schema. `shared/src/main/assets/public-app-config.json` is the packaged default and defines the visual/app shell:
- `home.hero`, `home.moduleOrder`, `home.enabled`;
- `live`;
- `channels`;
- `tracks` visual registry;
- `hypepredict` presentation only;
- `tv.channelUrl` and `tv.programs`;
- `latest`.

External destinations must be credential-free HTTPS. Packaged images may use `/assets/media/...`; Admin local image uploads may be represented as bounded `data:image/png|jpeg|webp;base64,...` values for preview/export. Config validation blocks executable strings, credential-like field names, duplicate IDs, unsupported statuses and oversized payloads.

The presentation config does not contain HypePredict scoring weights or private analysis instructions.
