# PlayersHype Ecosystem V1.2 — product baseline

## Product rule
The ecosystem must be operable by a non-programmer. Normal administration is limited to actions such as:
- upload/change a photo;
- paste a YouTube, web or social link;
- write a title/description;
- choose a status;
- enable, hide or mark a module as coming soon;
- add/remove cards;
- reorder Home modules;
- preview, save and publish.

JSON/code is not part of the primary Admin workflow.

## PlayersHype TV
PlayersHype TV is primarily YouTube-based. The User App opens the configured PlayersHype TV YouTube channel as its principal destination. Individual programs may optionally point to a YouTube video, live or playlist. A program without a destination must not look broken; it is shown as `Próximamente` or hidden.

## Player Live
Admin pastes an HTTPS YouTube live/video URL and selects the state. The public Home renders a visual card with the appropriate state. No embed code is required from the administrator.

## HypePredict protection
Do not alter HypePredict methodology, weights, analysis engine or private Prompt Maestro while changing Home/Admin presentation. Predict from the main app opens Track Hub; Track cards may deep-link to a track.

## Publication
The V1.2 local no-code workflow is complete. Remote multi-device publication remains a backend concern and must not be faked. It requires PlayersHype Core authentication, role enforcement, configuration/media storage, revision history and rollback.
