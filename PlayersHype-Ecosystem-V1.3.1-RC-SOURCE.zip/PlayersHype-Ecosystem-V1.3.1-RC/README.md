# PlayersHype Android Ecosystem V1.3.1 RC

V1.3.1 RC closes the publication split. It preserves the V1.3 RC Home, Control Center, Track Hub and HypePredict V1 analysis/rendering core.

## Publication contract

- **ACTUALIZAR APP** publishes only `main/docs/app/index.html`.
- **ACTUALIZAR LIVE** publishes only `main/docs/index.html`.
- Neither action triggers the other.
- The public Android app refreshes only from `docs/app/index.html`.
- GitHub Pages may serve `docs/index.html` as the HypePredict web Live.
- The old Cloudflare HypePredict Live endpoint is not used by the new publisher.
- GitHub credentials remain Admin-only and encrypted with Android Keystore.
- Pasted tokens are normalized to remove clipboard whitespace and zero-width characters before validation.
- Control Center includes **Probar conexión** before publication.

## HypePredict V1

The scoring engine, weights, methodology and analysis/rendering core are unchanged. Publication plumbing remains outside the model.
